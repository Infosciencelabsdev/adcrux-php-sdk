Template copyright belongs to 99designs.com
It was downloaded from http://99designs.com/customer-blog/99designs-introduces-email-design-category/ 
where it was offered as a free email template.  
